# server-ime 中文输入法：安装包内快速说明

本安装包内含：拼音引擎、IBus 平台适配、个人词库学习、候选面板与中文设置界面、统一入口
`bin/server-ime`，以及许可与来源材料。安装包与源码包、校验和、构建记录均在发布目录
`delivery/dist/`；完整中文文档见发布目录 `delivery/docs/使用指南.md`（含故障排查与证据索引）。

## 1. 安装（用户级，无需 root）

    python3 delivery/bin/ime-install install delivery/dist/server-ime-0.1.6.tar.gz \
        --prefix "$HOME/.local/opt/server-ime" \
        --data-dir "$HOME/.local/share/server-ime" --json

安装后入口为 `<prefix>/bin/server-ime`，个人数据在 `--data-dir`（默认
`$XDG_DATA_HOME/server-ime`），与安装前缀分离，升级/回滚/卸载默认保留。

## 2. 启动与使用

    <prefix>/bin/server-ime --data-dir "$HOME/.local/share/server-ime" \
        --state-dir "$HOME/.cache/server-ime/run" start --managed-ibus
    <prefix>/bin/server-ime --state-dir "$HOME/.cache/server-ime/run" exec -- <应用>
    <prefix>/bin/server-ime --state-dir "$HOME/.cache/server-ime/run" stop

中英切换 `Ctrl+Space`；数字/空格/鼠标选词；Page Up/Down 翻页；`Enter` 提交原拼音；
`Esc` 取消。需要可用的 X11 `DISPLAY`/`XAUTHORITY` 与会话总线；无图形会话时 `start` 会失败。

本版单一候选窗、完整候选页及布局后高亮滚动、短页宽度收缩；上屏后隐藏候选，不提供连续联想。
产品只使用自绘候选窗，应用内预编辑仍保留；用户实机双框是否消失待反馈。
升级或回滚前先 stop，完成后用相同配置、数据及 state 路径重新 start 并重新启动应用。

## 3. 设置、升级、回滚、卸载与诊断

    <prefix>/bin/server-ime --state-dir "$HOME/.cache/server-ime/run" settings          # 中文设置界面
    python3 delivery/bin/ime-install upgrade delivery/dist/server-ime-0.1.6.tar.gz --prefix <prefix>
    python3 delivery/bin/ime-install rollback --prefix <prefix>
    python3 delivery/bin/ime-install uninstall --prefix <prefix>
    python3 delivery/bin/ime-diagnose --prefix <prefix> --data-dir <datadir> --json

退出码：0 成功；2 参数/策略拒绝；5 校验失败；6 前缀并发占用。

## 4. 常见故障

| 现象 | 处理 |
| --- | --- |
| `Gtk couldn't be initialized` / `panel exited before ready` | 检查 `DISPLAY`、`XAUTHORITY` 是否属于当前会话 |
| `Explicit DISPLAY and DBUS_SESSION_BUS_ADDRESS are required` | 在桌面会话内运行，或 `dbus-run-session -- …` |
| `socket path too long` | 用较短的 `--state-dir`（如 `~/.cache/si/run`） |
| 安装报系统目录/退出码 2 | 前缀须为用户可写的绝对路径 |
| `verify` 报文件漂移（退出码 5） | 同版本 `--repair`，或升级/回滚到干净版本 |
| 候选不出现 | 应用须经 `server-ime exec --` 启动，且 `IBUS_ADDRESS` 属于受管 daemon |

## 5. 许可与来源

| 范围 | 许可 | 包内许可文件 |
| --- | --- | --- |
| engine / lexicon 代码 / interface / integration | GPL-3.0-or-later | `engine/LICENSE`、`lexicon/licenses/GPL-3.0.txt`、`interface/LICENSE`、`integration/LICENSE` |
| platform | MIT | `platform/LICENSE` |
| 词库增强数据（CC-BY-4.0） | CC-BY-4.0 | `lexicon/SOURCES.md` |
| interface 第三方依赖 | 各自上游许可 | `interface/SOURCES.md` |

对应源码、构建材料与上述许可原文在发布目录的 `-sources.tar.gz` 中；详见
`delivery/docs/licenses.md` 与包内 `share/ime/release.json` 的 `license_material` 字段。
本服务器无 Windows 11 运行环境，未做同机对照，不声称达到 Windows 11 水平。
